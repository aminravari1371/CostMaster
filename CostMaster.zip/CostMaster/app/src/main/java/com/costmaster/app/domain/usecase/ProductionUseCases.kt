package com.costmaster.app.domain.usecase

import com.costmaster.app.domain.model.Production
import com.costmaster.app.domain.model.ProductionMaterial
import com.costmaster.app.domain.model.Product
import com.costmaster.app.domain.repository.MaterialRepository
import com.costmaster.app.domain.repository.ProductionRepository
import com.costmaster.app.domain.repository.ProductRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import java.math.BigDecimal
import javax.inject.Inject

/**
 * مورد استفاده برای دریافت تمام تولیدات
 */
class GetAllProductionsUseCase @Inject constructor(
    private val repository: ProductionRepository
) {
    operator fun invoke(): Flow<List<Production>> = repository.getAllProductions()
}

/**
 * مورد استفاده برای دریافت تولیدات اخیر
 */
class GetRecentProductionsUseCase @Inject constructor(
    private val repository: ProductionRepository
) {
    operator fun invoke(limit: Int = 10): Flow<List<Production>> = repository.getRecentProductions(limit)
}

/**
 * مورد استفاده برای ثبت تولید جدید
 */
class CreateProductionUseCase @Inject constructor(
    private val productionRepository: ProductionRepository,
    private val productRepository: ProductRepository,
    private val materialRepository: MaterialRepository
) {
    suspend operator fun invoke(
        product: Product,
        quantity: Int
    ): Result<Production> {
        return try {
            // دریافت فرمول محصول
            val formula = productRepository.getProductFormula(product.id).first()

            if (formula.isEmpty()) {
                return Result.failure(Exception("فرمول ساخت محصول تعریف نشده است"))
            }

            // بررسی موجودی کافی مواد
            val missingMaterials = mutableListOf<String>()
            val materialsToDeduct = mutableListOf<Pair<Long, BigDecimal>>()

            for (formulaItem in formula) {
                val material = materialRepository.getMaterialById(formulaItem.materialId).first()
                if (material != null) {
                    val totalNeeded = formulaItem.quantityRequired * BigDecimal(quantity)
                    if (material.currentStock < totalNeeded) {
                        missingMaterials.add("${material.name}: نیاز ${totalNeeded} - موجود ${material.currentStock}")
                    } else {
                        materialsToDeduct.add(formulaItem.materialId to totalNeeded)
                    }
                }
            }

            if (missingMaterials.isNotEmpty()) {
                return Result.failure(
                    InsufficientMaterialsException(missingMaterials)
                )
            }

            // محاسبه هزینه مواد
            var totalMaterialCost = BigDecimal.ZERO
            val productionMaterials = mutableListOf<ProductionMaterial>()

            for (formulaItem in formula) {
                val material = materialRepository.getMaterialById(formulaItem.materialId).first()!!
                val totalNeeded = formulaItem.quantityRequired * BigDecimal(quantity)
                val materialTotalCost = material.purchasePrice * totalNeeded
                totalMaterialCost += materialTotalCost

                productionMaterials.add(
                    ProductionMaterial(
                        productionId = 0,
                        materialId = material.id,
                        materialName = material.name,
                        quantityUsed = totalNeeded,
                        materialUnit = material.unit,
                        unitCost = material.purchasePrice,
                        totalCost = materialTotalCost
                    )
                )
            }

            // محاسبه سربار
            val totalOverhead = product.overheadPerUnit * BigDecimal(quantity)
            val overheadPerUnit = product.overheadPerUnit
            val costPerUnit = if (quantity > 0) {
                (totalMaterialCost + totalOverhead) / BigDecimal(quantity)
            } else {
                BigDecimal.ZERO
            }

            val totalCost = totalMaterialCost + totalOverhead

            // ثبت تولید
            val production = Production(
                productId = product.id,
                productName = product.name,
                quantity = quantity,
                totalCost = totalCost,
                costPerUnit = costPerUnit,
                materialCost = totalMaterialCost,
                overheadCost = totalOverhead
            )

            val productionId = productionRepository.insertProduction(production)

            // کسر مواد از انبار
            for ((materialId, amount) in materialsToDeduct) {
                val material = materialRepository.getMaterialById(materialId).first()!!
                val newStock = material.currentStock - amount
                materialRepository.updateStock(materialId, newStock)
            }

            // افزودن موجودی محصول
            productRepository.updateProductStock(product.id, quantity)

            // ذخیره جزئیات مواد مصرفی
            val productionMaterialsWithId = productionMaterials.map {
                it.copy(productionId = productionId)
            }
            productionRepository.insertProductionMaterials(productionMaterialsWithId)

            Result.success(production.copy(id = productionId))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

class InsufficientMaterialsException(
    val missingMaterials: List<String>
) : Exception("مواد کافی نیست")
