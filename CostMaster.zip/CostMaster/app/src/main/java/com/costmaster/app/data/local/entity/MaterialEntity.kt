package com.costmaster.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.math.BigDecimal

/**
 * موجودیت ماده اولیه در پایگاه داده
 */
@Entity(tableName = "materials")
data class MaterialEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val unit: String,
    val purchasePrice: String, // BigDecimal stored as String
    val currentStock: String, // BigDecimal stored as String
    val reorderPoint: String, // BigDecimal stored as String
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

/**
 * موجودیت محصول در پایگاه داده
 */
@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val salePrice: String, // BigDecimal stored as String
    val currentStock: Int = 0,
    val overheadPerUnit: String, // BigDecimal stored as String
    val estimatedCost: String, // BigDecimal stored as String
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

/**
 * موجودیت ارتباط محصول و ماده اولیه (فرمول ساخت)
 */
@Entity(
    tableName = "product_materials",
    primaryKeys = ["productId", "materialId"]
)
data class ProductMaterialEntity(
    val productId: Long,
    val materialId: Long,
    val materialName: String,
    val quantityRequired: String, // BigDecimal stored as String
    val materialUnit: String,
    val createdAt: Long = System.currentTimeMillis()
)
