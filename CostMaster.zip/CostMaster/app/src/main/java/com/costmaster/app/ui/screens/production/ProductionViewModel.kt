package com.costmaster.app.ui.screens.production

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.costmaster.app.domain.model.Production
import com.costmaster.app.domain.model.Product
import com.costmaster.app.domain.model.ProductMaterial
import com.costmaster.app.domain.usecase.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.math.BigDecimal
import javax.inject.Inject

/**
 * حالت صفحه تولید
 */
data class ProductionUiState(
    val recentProductions: List<Production> = emptyList(),
    val allProductions: List<Production> = emptyList(),
    val products: List<Product> = emptyList(),
    val isLoading: Boolean = true,
    val error: String? = null,
    val successMessage: String? = null
)

/**
 * ViewModel برای صفحه تولید
 */
@HiltViewModel
class ProductionViewModel @Inject constructor(
    private val getRecentProductionsUseCase: GetRecentProductionsUseCase,
    private val getAllProductionsUseCase: GetAllProductionsUseCase,
    private val getAllProductsUseCase: GetAllProductsUseCase,
    private val createProductionUseCase: CreateProductionUseCase,
    private val getProductFormulaUseCase: GetProductFormulaUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(ProductionUiState())
    val uiState: StateFlow<ProductionUiState> = _uiState.asStateFlow()

    private val _selectedProduct = MutableStateFlow<Product?>(null)
    val selectedProduct: StateFlow<Product?> = _selectedProduct.asStateFlow()

    private val _productFormula = MutableStateFlow<List<ProductMaterial>>(emptyList())
    val productFormula: StateFlow<List<ProductMaterial>> = _productFormula.asStateFlow()

    init {
        loadData()
    }

    private fun loadData() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            try {
                combine(
                    getRecentProductionsUseCase(20),
                    getAllProductionsUseCase(),
                    getAllProductsUseCase()
                ) { recent, all, products ->
                    _uiState.update {
                        it.copy(
                            recentProductions = recent,
                            allProductions = all,
                            products = products,
                            isLoading = false
                        )
                    }
                }.collect()
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        error = e.message
                    )
                }
            }
        }
    }

    fun selectProduct(product: Product) {
        _selectedProduct.value = product
        viewModelScope.launch {
            getProductFormulaUseCase(product.id).collect { formula ->
                _productFormula.value = formula
            }
        }
    }

    fun createProduction(product: Product, quantity: Int): Result<Production> {
        var result: Result<Production>? = null
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            try {
                result = createProductionUseCase(product, quantity)
                if (result!!.isSuccess) {
                    _uiState.update { it.copy(successMessage = "تولید با موفقیت ثبت شد") }
                    loadData()
                } else {
                    _uiState.update { it.copy(error = result!!.exceptionOrNull()?.message) }
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(error = e.message) }
            } finally {
                _uiState.update { it.copy(isLoading = false) }
            }
        }
        return result ?: Result.failure(Exception("Unknown error"))
    }

    fun clearError() {
        _uiState.update { it.copy(error = null) }
    }

    fun clearSuccess() {
        _uiState.update { it.copy(successMessage = null) }
    }
}
