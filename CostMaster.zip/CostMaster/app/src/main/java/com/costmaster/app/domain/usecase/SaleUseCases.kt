package com.costmaster.app.domain.usecase

import com.costmaster.app.domain.model.Product
import com.costmaster.app.domain.model.Sale
import com.costmaster.app.domain.repository.ProductRepository
import com.costmaster.app.domain.repository.SaleRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import java.math.BigDecimal
import javax.inject.Inject

/**
 * مورد استفاده برای دریافت تمام فروش‌ها
 */
class GetAllSalesUseCase @Inject constructor(
    private val repository: SaleRepository
) {
    operator fun invoke(): Flow<List<Sale>> = repository.getAllSales()
}

/**
 * مورد استفاده برای دریافت فروش‌های اخیر
 */
class GetRecentSalesUseCase @Inject constructor(
    private val repository: SaleRepository
) {
    operator fun invoke(limit: Int = 10): Flow<List<Sale>> = repository.getRecentSales(limit)
}

/**
 * مورد استفاده برای ثبت فروش جدید
 */
class CreateSaleUseCase @Inject constructor(
    private val saleRepository: SaleRepository,
    private val productRepository: ProductRepository
) {
    suspend operator fun invoke(
        product: Product,
        quantity: Int,
        unitPrice: BigDecimal
    ): Result<Sale> {
        return try {
            // بررسی موجودی کافی
            if (product.currentStock < quantity) {
                return Result.failure(
                    InsufficientStockException(
                        available = product.currentStock,
                        requested = quantity
                    )
                )
            }

            // محاسبه مبالغ
            val totalRevenue = unitPrice * BigDecimal(quantity)
            val costPerUnit = product.estimatedCost
            val totalCost = costPerUnit * BigDecimal(quantity)
            val grossProfit = totalRevenue - totalCost

            // ثبت فروش
            val sale = Sale(
                productId = product.id,
                productName = product.name,
                quantity = quantity,
                unitPrice = unitPrice,
                totalRevenue = totalRevenue,
                costPerUnit = costPerUnit,
                totalCost = totalCost,
                grossProfit = grossProfit
            )

            val saleId = saleRepository.insertSale(sale)

            // کسر موجودی محصول
            productRepository.updateProductStock(product.id, -quantity)

            Result.success(sale.copy(id = saleId))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

class InsufficientStockException(
    val available: Int,
    val requested: Int
) : Exception("موجودی کافی نیست. موجودی: $available - درخواستی: $requested")
