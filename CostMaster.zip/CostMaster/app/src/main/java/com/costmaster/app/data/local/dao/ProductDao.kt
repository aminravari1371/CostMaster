package com.costmaster.app.data.local.dao

import androidx.room.*
import com.costmaster.app.data.local.entity.ProductEntity
import com.costmaster.app.data.local.entity.ProductMaterialEntity
import kotlinx.coroutines.flow.Flow

/**
 * DAO برای عملیات محصولات
 */
@Dao
interface ProductDao {
    @Query("SELECT * FROM products ORDER BY name ASC")
    fun getAllProducts(): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products WHERE id = :id")
    fun getProductById(id: Long): Flow<ProductEntity?>

    @Query("SELECT * FROM products WHERE name LIKE '%' || :query || '%' ORDER BY name ASC")
    fun searchProducts(query: String): Flow<List<ProductEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProduct(product: ProductEntity): Long

    @Update
    suspend fun updateProduct(product: ProductEntity)

    @Delete
    suspend fun deleteProduct(product: ProductEntity)

    @Query("UPDATE products SET currentStock = currentStock + :quantityChange, updatedAt = :updatedAt WHERE id = :productId")
    suspend fun updateProductStock(productId: Long, quantityChange: Int, updatedAt: Long = System.currentTimeMillis())

    @Query("SELECT * FROM products WHERE id = :productId")
    suspend fun getProductByIdSync(productId: Long): ProductEntity?

    // فرمول ساخت محصول
    @Query("SELECT * FROM product_materials WHERE productId = :productId")
    fun getProductFormula(productId: Long): Flow<List<ProductMaterialEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addMaterialToProduct(productMaterial: ProductMaterialEntity)

    @Query("DELETE FROM product_materials WHERE productId = :productId AND materialId = :materialId")
    suspend fun removeMaterialFromProduct(productId: Long, materialId: Long)

    @Query("DELETE FROM product_materials WHERE productId = :productId")
    suspend fun deleteAllProductMaterials(productId: Long)

    @Query("UPDATE products SET estimatedCost = :cost, updatedAt = :updatedAt WHERE id = :productId")
    suspend fun updateEstimatedCost(productId: Long, cost: String, updatedAt: Long = System.currentTimeMillis())
}
