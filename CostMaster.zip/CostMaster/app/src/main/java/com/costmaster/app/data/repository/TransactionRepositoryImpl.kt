package com.costmaster.app.data.repository

import com.costmaster.app.data.local.dao.ProductionDao
import com.costmaster.app.data.local.dao.SaleDao
import com.costmaster.app.data.mapper.toDomain
import com.costmaster.app.data.mapper.toEntity
import com.costmaster.app.domain.model.Production
import com.costmaster.app.domain.model.ProductionMaterial
import com.costmaster.app.domain.model.Sale
import com.costmaster.app.domain.repository.ProductionRepository
import com.costmaster.app.domain.repository.SaleRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.Calendar
import javax.inject.Inject

/**
 * پیاده‌سازی مخزن تولید
 */
class ProductionRepositoryImpl @Inject constructor(
    private val productionDao: ProductionDao
) : ProductionRepository {

    override fun getAllProductions(): Flow<List<Production>> =
        productionDao.getAllProductions().map { entities ->
            entities.map { it.toDomain() }
        }

    override fun getProductionById(id: Long): Flow<Production?> =
        productionDao.getProductionById(id).map { it?.toDomain() }

    override fun getProductionsByProduct(productId: Long): Flow<List<Production>> =
        productionDao.getProductionsByProduct(productId).map { entities ->
            entities.map { it.toDomain() }
        }

    override fun getRecentProductions(limit: Int): Flow<List<Production>> =
        productionDao.getRecentProductions(limit).map { entities ->
            entities.map { it.toDomain() }
        }

    override fun getProductionsByDateRange(startDate: Long, endDate: Long): Flow<List<Production>> =
        productionDao.getProductionsByDateRange(startDate, endDate).map { entities ->
            entities.map { it.toDomain() }
        }

    override suspend fun insertProduction(production: Production): Long =
        productionDao.insertProduction(production.toEntity())

    override suspend fun insertProductionMaterials(materials: List<ProductionMaterial>) =
        productionDao.insertProductionMaterials(materials.map { it.toEntity() })

    override fun getProductionMaterials(productionId: Long): Flow<List<ProductionMaterial>> =
        productionDao.getProductionMaterials(productionId).map { entities ->
            entities.map { it.toDomain() }
        }

    override suspend fun deleteProduction(production: Production) =
        productionDao.deleteProduction(production.toEntity())
}

/**
 * پیاده‌سازی مخزن فروش
 */
class SaleRepositoryImpl @Inject constructor(
    private val saleDao: SaleDao
) : SaleRepository {

    override fun getAllSales(): Flow<List<Sale>> =
        saleDao.getAllSales().map { entities ->
            entities.map { it.toDomain() }
        }

    override fun getSaleById(id: Long): Flow<Sale?> =
        saleDao.getSaleById(id).map { it?.toDomain() }

    override fun getSalesByProduct(productId: Long): Flow<List<Sale>> =
        saleDao.getSalesByProduct(productId).map { entities ->
            entities.map { it.toDomain() }
        }

    override fun getRecentSales(limit: Int): Flow<List<Sale>> =
        saleDao.getRecentSales(limit).map { entities ->
            entities.map { it.toDomain() }
        }

    override fun getSalesByDateRange(startDate: Long, endDate: Long): Flow<List<Sale>> =
        saleDao.getSalesByDateRange(startDate, endDate).map { entities ->
            entities.map { it.toDomain() }
        }

    override fun getTodaySales(): Flow<List<Sale>> {
        val calendar = Calendar.getInstance()
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        calendar.set(Calendar.MILLISECOND, 0)
        return saleDao.getTodaySales(calendar.timeInMillis).map { entities ->
            entities.map { it.toDomain() }
        }
    }

    override fun getMonthlySales(month: Int, year: Int): Flow<List<Sale>> {
        val calendar = Calendar.getInstance()
        calendar.set(year, month, 1, 0, 0, 0)
        calendar.set(Calendar.MILLISECOND, 0)
        val startOfMonth = calendar.timeInMillis

        calendar.add(Calendar.MONTH, 1)
        val endOfMonth = calendar.timeInMillis

        return saleDao.getMonthlySales(startOfMonth, endOfMonth).map { entities ->
            entities.map { it.toDomain() }
        }
    }

    override suspend fun insertSale(sale: Sale): Long =
        saleDao.insertSale(sale.toEntity())

    override suspend fun deleteSale(sale: Sale) =
        saleDao.deleteSale(sale.toEntity())
}
