package com.costmaster.app.domain.repository

import com.costmaster.app.domain.model.Material
import kotlinx.coroutines.flow.Flow

/**
 * اینترفیس مخزن مواد اولیه
 */
interface MaterialRepository {
    fun getAllMaterials(): Flow<List<Material>>
    fun getMaterialById(id: Long): Flow<Material?>
    fun searchMaterials(query: String): Flow<List<Material>>
    suspend fun insertMaterial(material: Material): Long
    suspend fun updateMaterial(material: Material)
    suspend fun deleteMaterial(material: Material)
    suspend fun updateStock(materialId: Long, newStock: java.math.BigDecimal)
    suspend fun addToStock(materialId: Long, quantity: java.math.BigDecimal, purchasePrice: java.math.BigDecimal)
    fun getLowStockMaterials(): Flow<List<Material>>
}
