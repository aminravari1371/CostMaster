package com.costmaster.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.costmaster.app.domain.model.Material
import com.costmaster.app.domain.model.MaterialUnit
import com.costmaster.app.domain.model.Product
import com.costmaster.app.domain.model.ProductMaterial
import com.costmaster.app.ui.screens.inventory.InventoryViewModel
import java.math.BigDecimal
import java.text.NumberFormat
import java.util.*

/**
 * صفحه تعریف فرمول ساخت محصول
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductFormulaScreen(
    productId: Long,
    onNavigateBack: () -> Unit,
    viewModel: InventoryViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    var showAddMaterialDialog by remember { mutableStateOf(false) }
    var showOverheadDialog by remember { mutableStateOf(false) }

    // یافتن محصول
    val product = uiState.products.find { it.id == productId }

    if (product == null) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator()
        }
        return
    }

    // فیلتر کردن مواد اضافه شده
    val existingMaterialIds = remember(productId) {
        uiState.materials.filter { material ->
            uiState.products.find { it.id == productId }?.let { prod ->
                // اینجا نیاز به دسترسی به فرمول است - ساده‌سازی شده
                false
            } ?: false
        }.map { it.id }.toSet()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("فرمول ساخت: ${product.name}") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        },
        floatingActionButton = {
            Column {
                FloatingActionButton(
                    onClick = { showAddMaterialDialog = true },
                    containerColor = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.padding(bottom = 16.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "افزودن ماده")
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
        ) {
            // اطلاعات محصول
            Card(
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = "اطلاعات محصول",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("قیمت فروش:")
                        Text(
                            "${NumberFormat.getNumberInstance(Locale.getDefault()).format(product.salePrice)} تومان",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // سربار
            Card(
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "سربار برای هر واحد",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            text = "${NumberFormat.getNumberInstance(Locale.getDefault()).format(product.overheadPerUnit)} تومان",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    OutlinedButton(onClick = { showOverheadDialog = true }) {
                        Text("ویرایش")
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // مواد فرمول
            Text(
                text = "مواد تشکیل‌دهنده",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(8.dp))

            // لیست مواد اضافه شده (نمونه)
            Card(
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = "برای افزودن مواد به فرمول، دکمه + را بزنید",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(80.dp)) // فضای دکمه شناور
        }

        // دیالوگ افزودن ماده
        if (showAddMaterialDialog) {
            AddMaterialToFormulaDialog(
                materials = uiState.materials,
                onDismiss = { showAddMaterialDialog = false },
                onConfirm = { material, quantity ->
                    // افزودن ماده به فرمول
                    showAddMaterialDialog = false
                }
            )
        }

        // دیالوگ ویرایش سربار
        if (showOverheadDialog) {
            OverheadDialog(
                currentValue = product.overheadPerUnit,
                onDismiss = { showOverheadDialog = false },
                onConfirm = { newValue ->
                    // به‌روزرسانی سربار
                    showOverheadDialog = false
                }
            )
        }
    }
}

@Composable
fun AddMaterialToFormulaDialog(
    materials: List<Material>,
    onDismiss: () -> Unit,
    onConfirm: (Material, BigDecimal) -> Unit
) {
    var selectedMaterial by remember { mutableStateOf<Material?>(null) }
    var quantity by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(false) }

    val isFormValid = selectedMaterial != null &&
            (quantity.toBigOrNull() ?: BigDecimal.ZERO) > BigDecimal.ZERO

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("افزودن ماده به فرمول") },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                ExposedDropdownMenuBox(
                    expanded = expanded,
                    onExpandedChange = { expanded = !expanded }
                ) {
                    OutlinedTextField(
                        value = selectedMaterial?.name ?: "",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("انتخاب ماده") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor()
                    )
                    ExposedDropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false }
                    ) {
                        materials.forEach { material ->
                            DropdownMenuItem(
                                text = {
                                    Text("${material.name} (${material.currentStock} ${material.unit.displayName})")
                                },
                                onClick = {
                                    selectedMaterial = material
                                    expanded = false
                                }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = quantity,
                    onValueChange = { quantity = it },
                    label = { Text("مقدار مورد نیاز برای هر واحد محصول") },
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    supportingText = {
                        selectedMaterial?.let {
                            Text("${it.unit.displayName}")
                        }
                    }
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    selectedMaterial?.let { material ->
                        onConfirm(material, quantity.toBigOrNull() ?: BigDecimal.ONE)
                    }
                },
                enabled = isFormValid
            ) {
                Text("افزودن")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("لغو")
            }
        }
    )
}

@Composable
fun OverheadDialog(
    currentValue: BigDecimal,
    onDismiss: () -> Unit,
    onConfirm: (BigDecimal) -> Unit
) {
    var value by remember { mutableStateOf(currentValue.toPlainString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("سربار برای هر واحد") },
        text = {
            Column {
                Text(
                    text = "هزینه‌های ثابت (دستمزد، برق، اجاره و...) را به ازای هر واحد محاسبه کنید",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(16.dp))
                OutlinedTextField(
                    value = value,
                    onValueChange = { value = it },
                    label = { Text("سربار هر واحد (تومان)") },
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val newValue = value.toBigOrNull() ?: BigDecimal.ZERO
                    onConfirm(newValue)
                }
            ) {
                Text("تأیید")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("لغو")
            }
        }
    )
}
