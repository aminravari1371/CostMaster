package com.costmaster.app.data.repository

import com.costmaster.app.data.local.dao.MaterialDao
import com.costmaster.app.data.local.dao.ProductDao
import com.costmaster.app.data.mapper.toDomain
import com.costmaster.app.data.mapper.toEntity
import com.costmaster.app.domain.model.Product
import com.costmaster.app.domain.model.ProductMaterial
import com.costmaster.app.domain.repository.ProductRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.math.BigDecimal
import javax.inject.Inject

/**
 * پیاده‌سازی مخزن محصولات
 */
class ProductRepositoryImpl @Inject constructor(
    private val productDao: ProductDao,
    private val materialDao: MaterialDao
) : ProductRepository {

    override fun getAllProducts(): Flow<List<Product>> =
        productDao.getAllProducts().map { entities ->
            entities.map { it.toDomain() }
        }

    override fun getProductById(id: Long): Flow<Product?> =
        productDao.getProductById(id).map { it?.toDomain() }

    override fun searchProducts(query: String): Flow<List<Product>> =
        productDao.searchProducts(query).map { entities ->
            entities.map { it.toDomain() }
        }

    override suspend fun insertProduct(product: Product): Long =
        productDao.insertProduct(product.toEntity())

    override suspend fun updateProduct(product: Product) =
        productDao.updateProduct(product.toEntity().copy(updatedAt = System.currentTimeMillis()))

    override suspend fun deleteProduct(product: Product) =
        productDao.deleteProduct(product.toEntity())

    override suspend fun addMaterialToProduct(productMaterial: ProductMaterial) {
        productDao.addMaterialToProduct(productMaterial.toEntity())
        // Recalculate estimated cost
        val newCost = calculateProductCost(productMaterial.productId)
        productDao.updateEstimatedCost(productMaterial.productId, newCost.toPlainString())
    }

    override suspend fun removeMaterialFromProduct(productMaterial: ProductMaterial) {
        productDao.removeMaterialFromProduct(productMaterial.productId, productMaterial.materialId)
        // Recalculate estimated cost
        val newCost = calculateProductCost(productMaterial.productId)
        productDao.updateEstimatedCost(productMaterial.productId, newCost.toPlainString())
    }

    override fun getProductFormula(productId: Long): Flow<List<ProductMaterial>> =
        productDao.getProductFormula(productId).map { entities ->
            entities.map { it.toDomain() }
        }

    override suspend fun updateProductStock(productId: Long, quantityChange: Int) {
        productDao.updateProductStock(productId, quantityChange)
    }

    override suspend fun calculateProductCost(productId: Long): BigDecimal {
        val product = productDao.getProductByIdSync(productId) ?: return BigDecimal.ZERO
        val formula = productDao.getProductFormula(productId).first()

        var totalMaterialCost = BigDecimal.ZERO
        for (formulaItem in formula) {
            val material = materialDao.getMaterialByIdSync(formulaItem.materialId)
            if (material != null) {
                val quantityRequired = BigDecimal(formulaItem.quantityRequired)
                val materialPrice = BigDecimal(material.purchasePrice)
                totalMaterialCost += quantityRequired * materialPrice
            }
        }

        val overheadPerUnit = BigDecimal(product.overheadPerUnit)
        return totalMaterialCost + overheadPerUnit
    }
}
