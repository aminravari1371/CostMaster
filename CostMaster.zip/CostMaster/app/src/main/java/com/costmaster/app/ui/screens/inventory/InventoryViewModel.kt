package com.costmaster.app.ui.screens.inventory

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.costmaster.app.domain.model.Material
import com.costmaster.app.domain.model.MaterialUnit
import com.costmaster.app.domain.model.Product
import com.costmaster.app.domain.usecase.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.math.BigDecimal
import javax.inject.Inject

/**
 * حالت صفحه انبار
 */
data class InventoryUiState(
    val materials: List<Material> = emptyList(),
    val products: List<Product> = emptyList(),
    val isLoading: Boolean = true,
    val error: String? = null,
    val searchQuery: String = "",
    val selectedTab: Int = 0
)

/**
 * ViewModel برای صفحه انبار
 */
@HiltViewModel
class InventoryViewModel @Inject constructor(
    private val getAllMaterialsUseCase: GetAllMaterialsUseCase,
    private val getAllProductsUseCase: GetAllProductsUseCase,
    private val searchMaterialsUseCase: SearchMaterialsUseCase,
    private val searchProductsUseCase: SearchProductsUseCase,
    private val addMaterialUseCase: AddMaterialUseCase,
    private val addProductUseCase: AddProductUseCase,
    private val addToStockUseCase: AddToStockUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(InventoryUiState())
    val uiState: StateFlow<InventoryUiState> = _uiState.asStateFlow()

    init {
        loadData()
    }

    private fun loadData() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            try {
                combine(
                    getAllMaterialsUseCase(),
                    getAllProductsUseCase()
                ) { materials, products ->
                    _uiState.update {
                        it.copy(
                            materials = materials,
                            products = products,
                            isLoading = false,
                            error = null
                        )
                    }
                }.collect()
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        error = e.message
                    )
                }
            }
        }
    }

    fun onSearchQueryChange(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
        if (query.isBlank()) {
            loadData()
        } else {
            viewModelScope.launch {
                if (_uiState.value.selectedTab == 0) {
                    searchMaterialsUseCase(query).collect { materials ->
                        _uiState.update { it.copy(materials = materials) }
                    }
                } else {
                    searchProductsUseCase(query).collect { products ->
                        _uiState.update { it.copy(products = products) }
                    }
                }
            }
        }
    }

    fun onTabSelected(tabIndex: Int) {
        _uiState.update { it.copy(selectedTab = tabIndex) }
    }

    fun addMaterial(
        name: String,
        unit: MaterialUnit,
        purchasePrice: BigDecimal,
        currentStock: BigDecimal,
        reorderPoint: BigDecimal
    ) {
        viewModelScope.launch {
            try {
                val material = Material(
                    name = name,
                    unit = unit,
                    purchasePrice = purchasePrice,
                    currentStock = currentStock,
                    reorderPoint = reorderPoint
                )
                addMaterialUseCase(material)
            } catch (e: Exception) {
                _uiState.update { it.copy(error = e.message) }
            }
        }
    }

    fun addProduct(name: String, salePrice: BigDecimal) {
        viewModelScope.launch {
            try {
                val product = Product(
                    name = name,
                    salePrice = salePrice
                )
                addProductUseCase(product)
            } catch (e: Exception) {
                _uiState.update { it.copy(error = e.message) }
            }
        }
    }

    fun addToStock(materialId: Long, quantity: BigDecimal, purchasePrice: BigDecimal) {
        viewModelScope.launch {
            try {
                addToStockUseCase(materialId, quantity, purchasePrice)
            } catch (e: Exception) {
                _uiState.update { it.copy(error = e.message) }
            }
        }
    }

    fun clearError() {
        _uiState.update { it.copy(error = null) }
    }
}
