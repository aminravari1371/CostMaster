package com.costmaster.app.di

import android.content.Context
import androidx.room.Room
import com.costmaster.app.data.local.CostMasterDatabase
import com.costmaster.app.data.local.dao.MaterialDao
import com.costmaster.app.data.local.dao.ProductDao
import com.costmaster.app.data.local.dao.ProductionDao
import com.costmaster.app.data.local.dao.SaleDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * ماژول Hilt برای پایگاه داده
 */
@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): CostMasterDatabase {
        return Room.databaseBuilder(
            context,
            CostMasterDatabase::class.java,
            CostMasterDatabase.DATABASE_NAME
        ).build()
    }

    @Provides
    @Singleton
    fun provideMaterialDao(database: CostMasterDatabase): MaterialDao {
        return database.materialDao()
    }

    @Provides
    @Singleton
    fun provideProductDao(database: CostMasterDatabase): ProductDao {
        return database.productDao()
    }

    @Provides
    @Singleton
    fun provideProductionDao(database: CostMasterDatabase): ProductionDao {
        return database.productionDao()
    }

    @Provides
    @Singleton
    fun provideSaleDao(database: CostMasterDatabase): SaleDao {
        return database.saleDao()
    }
}
