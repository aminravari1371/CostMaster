package com.costmaster.app.domain.repository

import com.costmaster.app.domain.model.Production
import com.costmaster.app.domain.model.ProductionMaterial
import kotlinx.coroutines.flow.Flow

/**
 * اینترفیس مخزن تولید
 */
interface ProductionRepository {
    fun getAllProductions(): Flow<List<Production>>
    fun getProductionById(id: Long): Flow<Production?>
    fun getProductionsByProduct(productId: Long): Flow<List<Production>>
    fun getRecentProductions(limit: Int): Flow<List<Production>>
    fun getProductionsByDateRange(startDate: Long, endDate: Long): Flow<List<Production>>
    suspend fun insertProduction(production: Production): Long
    suspend fun insertProductionMaterials(materials: List<ProductionMaterial>)
    fun getProductionMaterials(productionId: Long): Flow<List<ProductionMaterial>>
    suspend fun deleteProduction(production: Production)
}
