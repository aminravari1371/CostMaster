package com.costmaster.app.data.mapper

import com.costmaster.app.data.local.entity.*
import com.costmaster.app.domain.model.*
import java.math.BigDecimal

/**
 * توابع نگاشت برای تبدیل بین موجودیت‌های داده و مدل‌های دامنه
 */

// Material Mappers
fun MaterialEntity.toDomain(): Material = Material(
    id = id,
    name = name,
    unit = MaterialUnit.valueOf(unit),
    purchasePrice = BigDecimal(purchasePrice),
    currentStock = BigDecimal(currentStock),
    reorderPoint = BigDecimal(reorderPoint),
    createdAt = createdAt,
    updatedAt = updatedAt
)

fun Material.toEntity(): MaterialEntity = MaterialEntity(
    id = id,
    name = name,
    unit = unit.name,
    purchasePrice = purchasePrice.toPlainString(),
    currentStock = currentStock.toPlainString(),
    reorderPoint = reorderPoint.toPlainString(),
    createdAt = createdAt,
    updatedAt = updatedAt
)

// Product Mappers
fun ProductEntity.toDomain(): Product = Product(
    id = id,
    name = name,
    salePrice = BigDecimal(salePrice),
    currentStock = currentStock,
    overheadPerUnit = BigDecimal(overheadPerUnit),
    estimatedCost = BigDecimal(estimatedCost),
    createdAt = createdAt,
    updatedAt = updatedAt
)

fun Product.toEntity(): ProductEntity = ProductEntity(
    id = id,
    name = name,
    salePrice = salePrice.toPlainString(),
    currentStock = currentStock,
    overheadPerUnit = overheadPerUnit.toPlainString(),
    estimatedCost = estimatedCost.toPlainString(),
    createdAt = createdAt,
    updatedAt = updatedAt
)

// ProductMaterial Mappers
fun ProductMaterialEntity.toDomain(): ProductMaterial = ProductMaterial(
    id = 0,
    productId = productId,
    materialId = materialId,
    materialName = materialName,
    quantityRequired = BigDecimal(quantityRequired),
    materialUnit = MaterialUnit.valueOf(materialUnit),
    createdAt = createdAt
)

fun ProductMaterial.toEntity(): ProductMaterialEntity = ProductMaterialEntity(
    productId = productId,
    materialId = materialId,
    materialName = materialName,
    quantityRequired = quantityRequired.toPlainString(),
    materialUnit = materialUnit.name,
    createdAt = createdAt
)

// Production Mappers
fun ProductionEntity.toDomain(): Production = Production(
    id = id,
    productId = productId,
    productName = productName,
    quantity = quantity,
    totalCost = BigDecimal(totalCost),
    costPerUnit = BigDecimal(costPerUnit),
    materialCost = BigDecimal(materialCost),
    overheadCost = BigDecimal(overheadCost),
    timestamp = timestamp
)

fun Production.toEntity(): ProductionEntity = ProductionEntity(
    id = id,
    productId = productId,
    productName = productName,
    quantity = quantity,
    totalCost = totalCost.toPlainString(),
    costPerUnit = costPerUnit.toPlainString(),
    materialCost = materialCost.toPlainString(),
    overheadCost = overheadCost.toPlainString(),
    timestamp = timestamp
)

// ProductionMaterial Mappers
fun ProductionMaterialEntity.toDomain(): ProductionMaterial = ProductionMaterial(
    id = 0,
    productionId = productionId,
    materialId = materialId,
    materialName = materialName,
    quantityUsed = BigDecimal(quantityUsed),
    materialUnit = MaterialUnit.valueOf(materialUnit),
    unitCost = BigDecimal(unitCost),
    totalCost = BigDecimal(totalCost)
)

fun ProductionMaterial.toEntity(): ProductionMaterialEntity = ProductionMaterialEntity(
    productionId = productionId,
    materialId = materialId,
    materialName = materialName,
    quantityUsed = quantityUsed.toPlainString(),
    materialUnit = materialUnit.name,
    unitCost = unitCost.toPlainString(),
    totalCost = totalCost.toPlainString()
)

// Sale Mappers
fun SaleEntity.toDomain(): Sale = Sale(
    id = id,
    productId = productId,
    productName = productName,
    quantity = quantity,
    unitPrice = BigDecimal(unitPrice),
    totalRevenue = BigDecimal(totalRevenue),
    costPerUnit = BigDecimal(costPerUnit),
    totalCost = BigDecimal(totalCost),
    grossProfit = BigDecimal(grossProfit),
    timestamp = timestamp
)

fun Sale.toEntity(): SaleEntity = SaleEntity(
    id = id,
    productId = productId,
    productName = productName,
    quantity = quantity,
    unitPrice = unitPrice.toPlainString(),
    totalRevenue = totalRevenue.toPlainString(),
    costPerUnit = costPerUnit.toPlainString(),
    totalCost = totalCost.toPlainString(),
    grossProfit = grossProfit.toPlainString(),
    timestamp = timestamp
)

// Overhead Mappers
fun OverheadEntity.toDomain(): Overhead = Overhead(
    id = id,
    name = name,
    amount = BigDecimal(amount),
    type = OverheadType.valueOf(type),
    createdAt = createdAt
)

fun Overhead.toEntity(): OverheadEntity = OverheadEntity(
    id = id,
    name = name,
    amount = amount.toPlainString(),
    type = type.name,
    createdAt = createdAt
)
