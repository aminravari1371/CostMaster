package com.costmaster.app.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.ui.graphics.vector.ImageVector

/**
 * صفحات ناوبری اپلیکیشن
 */
sealed class Screen(
    val route: String,
    val title: String,
    val icon: ImageVector
) {
    data object Inventory : Screen(
        route = "inventory",
        title = "انبار",
        icon = Icons.Default.Inventory
    )

    data object Production : Screen(
        route = "production",
        title = "تولید",
        icon = Icons.Default.Add
    )

    data object Sales : Screen(
        route = "sales",
        title = "فروش",
        icon = Icons.Default.ShoppingCart
    )

    data object Reports : Screen(
        route = "reports",
        title = "گزارشات",
        icon = Icons.Default.Assessment
    )

    companion object {
        val bottomNavItems = listOf(Inventory, Production, Sales, Reports)
    }
}

/**
 * صفحات اضافی
 */
object Routes {
    const val ADD_MATERIAL = "add_material"
    const val ADD_PRODUCT = "add_product"
    const val PRODUCT_FORMULA = "product_formula/{productId}"
    const val NEW_PRODUCTION = "new_production"
    const val NEW_SALE = "new_sale"

    fun productFormula(productId: Long) = "product_formula/$productId"
}
