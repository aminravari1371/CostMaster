package com.costmaster.app.ui.screens.sales

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.costmaster.app.domain.model.Product
import com.costmaster.app.domain.model.Sale
import com.costmaster.app.domain.usecase.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.math.BigDecimal
import javax.inject.Inject

/**
 * حالت صفحه فروش
 */
data class SalesUiState(
    val recentSales: List<Sale> = emptyList(),
    val products: List<Product> = emptyList(),
    val isLoading: Boolean = true,
    val error: String? = null,
    val successMessage: String? = null
)

/**
 * ViewModel برای صفحه فروش
 */
@HiltViewModel
class SalesViewModel @Inject constructor(
    private val getRecentSalesUseCase: GetRecentSalesUseCase,
    private val getAllProductsUseCase: GetAllProductsUseCase,
    private val createSaleUseCase: CreateSaleUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(SalesUiState())
    val uiState: StateFlow<SalesUiState> = _uiState.asStateFlow()

    init {
        loadData()
    }

    private fun loadData() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            try {
                combine(
                    getRecentSalesUseCase(20),
                    getAllProductsUseCase()
                ) { sales, products ->
                    _uiState.update {
                        it.copy(
                            recentSales = sales,
                            products = products,
                            isLoading = false
                        )
                    }
                }.collect()
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        error = e.message
                    )
                }
            }
        }
    }

    fun createSale(
        product: Product,
        quantity: Int,
        unitPrice: BigDecimal
    ): Result<Sale> {
        var result: Result<Sale>? = null
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            try {
                result = createSaleUseCase(product, quantity, unitPrice)
                if (result!!.isSuccess) {
                    _uiState.update { it.copy(successMessage = "فروش با موفقیت ثبت شد") }
                    loadData()
                } else {
                    val error = result!!.exceptionOrNull()?.message ?: "خطا در ثبت فروش"
                    _uiState.update { it.copy(error = error) }
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(error = e.message) }
            } finally {
                _uiState.update { it.copy(isLoading = false) }
            }
        }
        return result ?: Result.failure(Exception("Unknown error"))
    }

    fun clearError() {
        _uiState.update { it.copy(error = null) }
    }

    fun clearSuccess() {
        _uiState.update { it.copy(successMessage = null) }
    }
}
