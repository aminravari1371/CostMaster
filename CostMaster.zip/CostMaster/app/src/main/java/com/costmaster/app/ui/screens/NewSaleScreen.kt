package com.costmaster.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.costmaster.app.domain.model.Product
import com.costmaster.app.ui.screens.sales.SalesViewModel
import java.math.BigDecimal
import java.text.NumberFormat
import java.util.*

/**
 * صفحه ثبت فروش جدید
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewSaleScreen(
    onNavigateBack: () -> Unit,
    viewModel: SalesViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    var selectedProduct by remember { mutableStateOf<Product?>(null) }
    var quantity by remember { mutableStateOf("1") }
    var unitPrice by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(false) }
    var showConfirmDialog by remember { mutableStateOf(false) }

    val format = NumberFormat.getNumberInstance(Locale.getDefault())

    // قیمت پیشنهادی بر اساس محصول انتخاب شده
    LaunchedEffect(selectedProduct) {
        selectedProduct?.let { product ->
            if (unitPrice.isBlank() || unitPrice.toBigOrNull() == product.salePrice) {
                unitPrice = if (product.salePrice > BigDecimal.ZERO) {
                    product.salePrice.toPlainString()
                } else {
                    ""
                }
            }
        }
    }

    val totalQuantity = quantity.toIntOrNull() ?: 0
    val pricePerUnit = unitPrice.toBigOrNull() ?: BigDecimal.ZERO
    val totalRevenue = pricePerUnit * BigDecimal(totalQuantity)
    val estimatedProfit = if (selectedProduct != null && totalQuantity > 0) {
        totalRevenue - (selectedProduct!!.estimatedCost * BigDecimal(totalQuantity))
    } else {
        BigDecimal.ZERO
    }

    val isFormValid = selectedProduct != null &&
            totalQuantity > 0 &&
            totalQuantity <= (selectedProduct?.currentStock ?: 0) &&
            pricePerUnit > BigDecimal.ZERO

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("ثبت فروش جدید") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // انتخاب محصول
            ExposedDropdownMenuBox(
                expanded = expanded,
                onExpandedChange = { expanded = !expanded }
            ) {
                OutlinedTextField(
                    value = selectedProduct?.name ?: "",
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("انتخاب محصول") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .menuAnchor()
                )
                ExposedDropdownMenu(
                    expanded = expanded,
                    onDismissRequest = { expanded = false }
                ) {
                    uiState.products.forEach { product ->
                        DropdownMenuItem(
                            text = {
                                Column {
                                    Text(product.name)
                                    Text(
                                        text = "موجودی: ${product.currentStock} عدد",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (product.currentStock == 0) {
                                            MaterialTheme.colorScheme.error
                                        } else {
                                            MaterialTheme.colorScheme.onSurfaceVariant
                                        }
                                    )
                                }
                            },
                            onClick = {
                                selectedProduct = product
                                expanded = false
                            }
                        )
                    }
                }
            }

            // نمایش موجودی و قیمت پایه
            selectedProduct?.let { product ->
                Card(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("موجودی:", style = MaterialTheme.typography.bodyMedium)
                            Text(
                                "${product.currentStock} عدد",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        if (product.salePrice > BigDecimal.ZERO) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("قیمت پایه:", style = MaterialTheme.typography.bodyMedium)
                                Text(
                                    "${format.format(product.salePrice)} تومان",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            // تعداد
            OutlinedTextField(
                value = quantity,
                onValueChange = { quantity = it },
                label = { Text("تعداد") },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                isError = selectedProduct?.let { it.currentStock < (quantity.toIntOrNull() ?: 0) } ?: false,
                supportingText = selectedProduct?.let {
                    if (it.currentStock < (quantity.toIntOrNull() ?: 0)) {
                        { Text("موجودی کافی نیست!") }
                    } else null
                }
            )

            // قیمت واحد
            OutlinedTextField(
                value = unitPrice,
                onValueChange = { unitPrice = it },
                label = { Text("قیمت واحد (تومان)") },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true
            )

            // خلاصه فروش
            if (totalQuantity > 0 && pricePerUnit > BigDecimal.ZERO) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "خلاصه فروش",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("مجموع درآمد:")
                            Text(
                                "${format.format(totalRevenue)} تومان",
                                fontWeight = FontWeight.Bold
                            )
                        }
                        if (selectedProduct != null) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("سود تخمینی:")
                                Text(
                                    "${format.format(estimatedProfit)} تومان",
                                    fontWeight = FontWeight.Bold,
                                    color = if (estimatedProfit >= BigDecimal.ZERO) {
                                        MaterialTheme.colorScheme.primary
                                    } else {
                                        MaterialTheme.colorScheme.error
                                    }
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            Button(
                onClick = { showConfirmDialog = true },
                modifier = Modifier.fillMaxWidth(),
                enabled = isFormValid
            ) {
                Text("ثبت فروش")
            }
        }

        // دیالوگ تأیید
        if (showConfirmDialog && selectedProduct != null) {
            ConfirmSaleDialog(
                productName = selectedProduct!!.name,
                quantity = totalQuantity,
                unitPrice = pricePerUnit,
                totalRevenue = totalRevenue,
                onConfirm = {
                    viewModel.createSale(selectedProduct!!, totalQuantity, pricePerUnit)
                    showConfirmDialog = false
                    onNavigateBack()
                },
                onDismiss = { showConfirmDialog = false }
            )
        }
    }
}

@Composable
fun ConfirmSaleDialog(
    productName: String,
    quantity: Int,
    unitPrice: BigDecimal,
    totalRevenue: BigDecimal,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    val format = NumberFormat.getNumberInstance(Locale.getDefault())

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تأیید فروش") },
        text = {
            Column {
                Text("محصول: $productName")
                Text("تعداد: $quantity")
                Text("قیمت واحد: ${format.format(unitPrice)} تومان")
                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                Text(
                    text = "مجموع درآمد: ${format.format(totalRevenue)} تومان",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        confirmButton = {
            Button(onClick = onConfirm) {
                Text("تأیید")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("لغو")
            }
        }
    )
}
