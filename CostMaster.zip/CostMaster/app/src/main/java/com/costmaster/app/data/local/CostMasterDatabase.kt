package com.costmaster.app.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.costmaster.app.data.local.dao.MaterialDao
import com.costmaster.app.data.local.dao.ProductDao
import com.costmaster.app.data.local.dao.ProductionDao
import com.costmaster.app.data.local.dao.SaleDao
import com.costmaster.app.data.local.entity.*

/**
 * پایگاه داده اصلی اپلیکیشن
 */
@Database(
    entities = [
        MaterialEntity::class,
        ProductEntity::class,
        ProductMaterialEntity::class,
        ProductionEntity::class,
        ProductionMaterialEntity::class,
        SaleEntity::class,
        OverheadEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class CostMasterDatabase : RoomDatabase() {
    abstract fun materialDao(): MaterialDao
    abstract fun productDao(): ProductDao
    abstract fun productionDao(): ProductionDao
    abstract fun saleDao(): SaleDao

    companion object {
        const val DATABASE_NAME = "costmaster_database"
    }
}
