package com.costmaster.app.domain.repository

import com.costmaster.app.domain.model.MaterialUnit
import com.costmaster.app.domain.model.Product
import com.costmaster.app.domain.model.ProductMaterial
import kotlinx.coroutines.flow.Flow

/**
 * اینترفیس مخزن محصولات
 */
interface ProductRepository {
    fun getAllProducts(): Flow<List<Product>>
    fun getProductById(id: Long): Flow<Product?>
    fun searchProducts(query: String): Flow<List<Product>>
    suspend fun insertProduct(product: Product): Long
    suspend fun updateProduct(product: Product)
    suspend fun deleteProduct(product: Product)

    // فرمول ساخت محصول
    suspend fun addMaterialToProduct(productMaterial: ProductMaterial)
    suspend fun removeMaterialFromProduct(productMaterial: ProductMaterial)
    fun getProductFormula(productId: Long): Flow<List<ProductMaterial>>
    suspend fun updateProductStock(productId: Long, quantityChange: Int)

    // محاسبه بهای تمام شده
    suspend fun calculateProductCost(productId: Long): java.math.BigDecimal
}
