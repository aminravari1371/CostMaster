package com.costmaster.app.domain.model

import java.math.BigDecimal

/**
 * نمایش یک محصول در سیستم
 */
data class Product(
    val id: Long = 0,
    val name: String,
    val salePrice: BigDecimal = BigDecimal.ZERO,
    val currentStock: Int = 0,
    val overheadPerUnit: BigDecimal = BigDecimal.ZERO,
    val estimatedCost: BigDecimal = BigDecimal.ZERO,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    val profitMargin: BigDecimal
        get() = if (estimatedCost > BigDecimal.ZERO) {
            salePrice - estimatedCost
        } else {
            BigDecimal.ZERO
        }

    val profitMarginPercent: BigDecimal
        get() = if (estimatedCost > BigDecimal.ZERO) {
            ((salePrice - estimatedCost) / estimatedCost) * BigDecimal(100)
        } else {
            BigDecimal.ZERO
        }
}

/**
 * ارتباط بین محصول و مواد اولیه (فرمول ساخت)
 */
data class ProductMaterial(
    val id: Long = 0,
    val productId: Long,
    val materialId: Long,
    val materialName: String,
    val quantityRequired: BigDecimal,
    val materialUnit: MaterialUnit,
    val createdAt: Long = System.currentTimeMillis()
) {
    val totalMaterialCost: BigDecimal
        get() = BigDecimal.ZERO // Calculated dynamically based on current material price
}
