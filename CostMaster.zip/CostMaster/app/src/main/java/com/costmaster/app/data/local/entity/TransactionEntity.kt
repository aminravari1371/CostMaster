package com.costmaster.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * موجودیت تولید در پایگاه داده
 */
@Entity(tableName = "productions")
data class ProductionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val productId: Long,
    val productName: String,
    val quantity: Int,
    val totalCost: String, // BigDecimal stored as String
    val costPerUnit: String, // BigDecimal stored as String
    val materialCost: String, // BigDecimal stored as String
    val overheadCost: String, // BigDecimal stored as String
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * موجودیت مواد مصرف شده در تولید
 */
@Entity(
    tableName = "production_materials",
    primaryKeys = ["productionId", "materialId"]
)
data class ProductionMaterialEntity(
    val productionId: Long,
    val materialId: Long,
    val materialName: String,
    val quantityUsed: String, // BigDecimal stored as String
    val materialUnit: String,
    val unitCost: String, // BigDecimal stored as String
    val totalCost: String // BigDecimal stored as String
)

/**
 * موجودیت فروش در پایگاه داده
 */
@Entity(tableName = "sales")
data class SaleEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val productId: Long,
    val productName: String,
    val quantity: Int,
    val unitPrice: String, // BigDecimal stored as String
    val totalRevenue: String, // BigDecimal stored as String
    val costPerUnit: String, // BigDecimal stored as String
    val totalCost: String, // BigDecimal stored as String
    val grossProfit: String, // BigDecimal stored as String
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * موجودیت سربار
 */
@Entity(tableName = "overheads")
data class OverheadEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val amount: String, // BigDecimal stored as String
    val type: String, // FIXED or PER_UNIT
    val createdAt: Long = System.currentTimeMillis()
)
