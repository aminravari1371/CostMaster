package com.costmaster.app.domain.usecase

import com.costmaster.app.domain.model.Material
import com.costmaster.app.domain.repository.MaterialRepository
import kotlinx.coroutines.flow.Flow
import java.math.BigDecimal
import javax.inject.Inject

/**
 * مورد استفاده برای دریافت تمام مواد اولیه
 */
class GetAllMaterialsUseCase @Inject constructor(
    private val repository: MaterialRepository
) {
    operator fun invoke(): Flow<List<Material>> = repository.getAllMaterials()
}

/**
 * مورد استفاده برای جستجوی مواد اولیه
 */
class SearchMaterialsUseCase @Inject constructor(
    private val repository: MaterialRepository
) {
    operator fun invoke(query: String): Flow<List<Material>> = repository.searchMaterials(query)
}

/**
 * مورد استفاده برای دریافت مواد با موجودی کم
 */
class GetLowStockMaterialsUseCase @Inject constructor(
    private val repository: MaterialRepository
) {
    operator fun invoke(): Flow<List<Material>> = repository.getLowStockMaterials()
}

/**
 * مورد استفاده برای افزودن ماده اولیه جدید
 */
class AddMaterialUseCase @Inject constructor(
    private val repository: MaterialRepository
) {
    suspend operator fun invoke(material: Material): Long = repository.insertMaterial(material)
}

/**
 * مورد استفاده برای به‌روزرسانی موجودی ماده اولیه
 */
class UpdateMaterialStockUseCase @Inject constructor(
    private val repository: MaterialRepository
) {
    suspend operator fun invoke(materialId: Long, quantity: BigDecimal) {
        repository.updateStock(materialId, quantity)
    }
}

/**
 * مورد استفاده برای افزودن به موجودی (خرید مجدد)
 */
class AddToStockUseCase @Inject constructor(
    private val repository: MaterialRepository
) {
    suspend operator fun invoke(
        materialId: Long,
        quantity: BigDecimal,
        purchasePrice: BigDecimal
    ) {
        repository.addToStock(materialId, quantity, purchasePrice)
    }
}
