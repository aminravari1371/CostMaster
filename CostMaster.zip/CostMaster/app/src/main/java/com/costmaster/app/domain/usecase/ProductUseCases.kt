package com.costmaster.app.domain.usecase

import com.costmaster.app.domain.model.Product
import com.costmaster.app.domain.model.ProductMaterial
import com.costmaster.app.domain.repository.ProductRepository
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

/**
 * مورد استفاده برای دریافت تمام محصولات
 */
class GetAllProductsUseCase @Inject constructor(
    private val repository: ProductRepository
) {
    operator fun invoke(): Flow<List<Product>> = repository.getAllProducts()
}

/**
 * مورد استفاده برای جستجوی محصولات
 */
class SearchProductsUseCase @Inject constructor(
    private val repository: ProductRepository
) {
    operator fun invoke(query: String): Flow<List<Product>> = repository.searchProducts(query)
}

/**
 * مورد استفاده برای افزودن محصول جدید
 */
class AddProductUseCase @Inject constructor(
    private val repository: ProductRepository
) {
    suspend operator fun invoke(product: Product): Long = repository.insertProduct(product)
}

/**
 * مورد استفاده برای دریافت فرمول ساخت محصول
 */
class GetProductFormulaUseCase @Inject constructor(
    private val repository: ProductRepository
) {
    operator fun invoke(productId: Long): Flow<List<ProductMaterial>> =
        repository.getProductFormula(productId)
}

/**
 * مورد استفاده برای افزودن ماده به فرمول محصول
 */
class AddMaterialToProductUseCase @Inject constructor(
    private val repository: ProductRepository
) {
    suspend operator fun invoke(productMaterial: ProductMaterial) {
        repository.addMaterialToProduct(productMaterial)
    }
}

/**
 * مورد استفاده برای حذف ماده از فرمول محصول
 */
class RemoveMaterialFromProductUseCase @Inject constructor(
    private val repository: ProductRepository
) {
    suspend operator fun invoke(productMaterial: ProductMaterial) {
        repository.removeMaterialFromProduct(productMaterial)
    }
}

/**
 * مورد استفاده برای محاسبه بهای تمام شده محصول
 */
class CalculateProductCostUseCase @Inject constructor(
    private val repository: ProductRepository
) {
    suspend operator fun invoke(productId: Long) = repository.calculateProductCost(productId)
}
