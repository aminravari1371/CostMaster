package com.costmaster.app

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

/**
 * کلاس اصلی اپلیکیشن
 */
@HiltAndroidApp
class CostMasterApp : Application()
