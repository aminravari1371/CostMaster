package com.costmaster.app.data.local.dao

import androidx.room.*
import com.costmaster.app.data.local.entity.MaterialEntity
import kotlinx.coroutines.flow.Flow

/**
 * DAO برای عملیات مواد اولیه
 */
@Dao
interface MaterialDao {
    @Query("SELECT * FROM materials ORDER BY name ASC")
    fun getAllMaterials(): Flow<List<MaterialEntity>>

    @Query("SELECT * FROM materials WHERE id = :id")
    fun getMaterialById(id: Long): Flow<MaterialEntity?>

    @Query("SELECT * FROM materials WHERE name LIKE '%' || :query || '%' ORDER BY name ASC")
    fun searchMaterials(query: String): Flow<List<MaterialEntity>>

    @Query("SELECT * FROM materials WHERE CAST(currentStock AS REAL) <= CAST(reorderPoint AS REAL)")
    fun getLowStockMaterials(): Flow<List<MaterialEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMaterial(material: MaterialEntity): Long

    @Update
    suspend fun updateMaterial(material: MaterialEntity)

    @Delete
    suspend fun deleteMaterial(material: MaterialEntity)

    @Query("UPDATE materials SET currentStock = :newStock, updatedAt = :updatedAt WHERE id = :materialId")
    suspend fun updateStock(materialId: Long, newStock: String, updatedAt: Long = System.currentTimeMillis())

    @Query("SELECT * FROM materials WHERE id = :materialId")
    suspend fun getMaterialByIdSync(materialId: Long): MaterialEntity?
}
