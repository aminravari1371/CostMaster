package com.costmaster.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.costmaster.app.domain.model.MaterialUnit
import com.costmaster.app.ui.screens.inventory.InventoryViewModel

/**
 * صفحه افزودن ماده اولیه جدید
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddMaterialScreen(
    onNavigateBack: () -> Unit,
    viewModel: InventoryViewModel = hiltViewModel()
) {
    var name by remember { mutableStateOf("") }
    var selectedUnit by remember { mutableStateOf(MaterialUnit.KILOGRAM) }
    var purchasePrice by remember { mutableStateOf("") }
    var currentStock by remember { mutableStateOf("") }
    var reorderPoint by remember { mutableStateOf("0") }
    var expanded by remember { mutableStateOf(false) }

    val isFormValid = name.isNotBlank() &&
            (purchasePrice.toBigOrNull() ?: BigDecimal.ZERO) > BigDecimal.ZERO &&
            (currentStock.toBigOrNull() ?: BigDecimal.ZERO) >= BigDecimal.ZERO

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("افزودن ماده اولیه") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("نام ماده اولیه") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            // انتخاب واحد
            ExposedDropdownMenuBox(
                expanded = expanded,
                onExpandedChange = { expanded = !expanded }
            ) {
                OutlinedTextField(
                    value = selectedUnit.displayName,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("واحد اندازه‌گیری") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .menuAnchor()
                )
                ExposedDropdownMenu(
                    expanded = expanded,
                    onDismissRequest = { expanded = false }
                ) {
                    MaterialUnit.entries.forEach { unit ->
                        DropdownMenuItem(
                            text = { Text(unit.displayName) },
                            onClick = {
                                selectedUnit = unit
                                expanded = false
                            }
                        )
                    }
                }
            }

            OutlinedTextField(
                value = purchasePrice,
                onValueChange = { purchasePrice = it },
                label = { Text("قیمت خرید (تومان)") },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true
            )

            OutlinedTextField(
                value = currentStock,
                onValueChange = { currentStock = it },
                label = { Text("موجودی اولیه") },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true
            )

            OutlinedTextField(
                value = reorderPoint,
                onValueChange = { reorderPoint = it },
                label = { Text("نقطه سفارش (اختیاری)") },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                supportingText = { Text("وقتی موجودی کمتر از این شود، هشدار نمایش داده می‌شود") }
            )

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {
                    viewModel.addMaterial(
                        name = name,
                        unit = selectedUnit,
                        purchasePrice = purchasePrice.toBigOrNull() ?: BigDecimal.ZERO,
                        currentStock = currentStock.toBigOrNull() ?: BigDecimal.ZERO,
                        reorderPoint = reorderPoint.toBigOrNull() ?: BigDecimal.ZERO
                    )
                    onNavigateBack()
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = isFormValid
            ) {
                Text("ذخیره")
            }
        }
    }
}
