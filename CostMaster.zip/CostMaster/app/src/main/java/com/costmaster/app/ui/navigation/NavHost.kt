package com.costmaster.app.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.costmaster.app.ui.screens.inventory.InventoryScreen
import com.costmaster.app.ui.screens.production.ProductionScreen
import com.costmaster.app.ui.screens.reports.ReportsScreen
import com.costmaster.app.ui.screens.sales.SalesScreen
import com.costmaster.app.ui.screens.AddMaterialScreen
import com.costmaster.app.ui.screens.AddProductScreen
import com.costmaster.app.ui.screens.NewProductionScreen
import com.costmaster.app.ui.screens.NewSaleScreen
import com.costmaster.app.ui.screens.ProductFormulaScreen

/**
 * میزبان ناوبری اصلی
 */
@Composable
fun CostMasterNavHost(
    navController: NavHostController,
    modifier: Modifier = Modifier
) {
    NavHost(
        navController = navController,
        startDestination = Screen.Inventory.route,
        modifier = modifier
    ) {
        // صفحه اصلی انبار
        composable(Screen.Inventory.route) {
            InventoryScreen(
                onAddMaterial = { navController.navigate(Routes.ADD_MATERIAL) },
                onAddProduct = { navController.navigate(Routes.ADD_PRODUCT) }
            )
        }

        // صفحه تولید
        composable(Screen.Production.route) {
            ProductionScreen(
                onNewProduction = { navController.navigate(Routes.NEW_PRODUCTION) }
            )
        }

        // صفحه فروش
        composable(Screen.Sales.route) {
            SalesScreen(
                onNewSale = { navController.navigate(Routes.NEW_SALE) }
            )
        }

        // صفحه گزارشات
        composable(Screen.Reports.route) {
            ReportsScreen()
        }

        // افزودن ماده اولیه
        composable(Routes.ADD_MATERIAL) {
            AddMaterialScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }

        // افزودن محصول
        composable(Routes.ADD_PRODUCT) {
            AddProductScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }

        // فرمول ساخت محصول
        composable(
            route = Routes.PRODUCT_FORMULA,
            arguments = listOf(navArgument("productId") { type = NavType.LongType })
        ) { backStackEntry ->
            val productId = backStackEntry.arguments?.getLong("productId") ?: return@composable
            ProductFormulaScreen(
                productId = productId,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        // ثبت تولید جدید
        composable(Routes.NEW_PRODUCTION) {
            NewProductionScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }

        // ثبت فروش جدید
        composable(Routes.NEW_SALE) {
            NewSaleScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }
    }
}
