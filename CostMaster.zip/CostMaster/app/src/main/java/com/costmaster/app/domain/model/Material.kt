package com.costmaster.app.domain.model

import java.math.BigDecimal

/**
 * نمایش یک ماده اولیه در سیستم
 */
data class Material(
    val id: Long = 0,
    val name: String,
    val unit: MaterialUnit,
    val purchasePrice: BigDecimal,
    val currentStock: BigDecimal = BigDecimal.ZERO,
    val reorderPoint: BigDecimal = BigDecimal.ZERO,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    val isLowStock: Boolean
        get() = currentStock <= reorderPoint

    val totalValue: BigDecimal
        get() = currentStock * purchasePrice
}

/**
 * واحدهای اندازه‌گیری مواد اولیه
 */
enum class MaterialUnit(val displayName: String) {
    KILOGRAM("کیلوگرم"),
    GRAM("گرم"),
    LITER("لیتر"),
    MILLILITER("میلی‌لیتر"),
    PIECE("عدد"),
    METER("متر");

    companion object {
        fun fromDisplayName(name: String): MaterialUnit {
            return entries.find { it.displayName == name } ?: PIECE
        }
    }
}
