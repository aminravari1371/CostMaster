package com.costmaster.app.data.local.dao

import androidx.room.*
import com.costmaster.app.data.local.entity.ProductionEntity
import com.costmaster.app.data.local.entity.ProductionMaterialEntity
import com.costmaster.app.data.local.entity.SaleEntity
import kotlinx.coroutines.flow.Flow

/**
 * DAO برای عملیات تولید
 */
@Dao
interface ProductionDao {
    @Query("SELECT * FROM productions ORDER BY timestamp DESC")
    fun getAllProductions(): Flow<List<ProductionEntity>>

    @Query("SELECT * FROM productions WHERE id = :id")
    fun getProductionById(id: Long): Flow<ProductionEntity?>

    @Query("SELECT * FROM productions WHERE productId = :productId ORDER BY timestamp DESC")
    fun getProductionsByProduct(productId: Long): Flow<List<ProductionEntity>>

    @Query("SELECT * FROM productions ORDER BY timestamp DESC LIMIT :limit")
    fun getRecentProductions(limit: Int): Flow<List<ProductionEntity>>

    @Query("SELECT * FROM productions WHERE timestamp BETWEEN :startDate AND :endDate ORDER BY timestamp DESC")
    fun getProductionsByDateRange(startDate: Long, endDate: Long): Flow<List<ProductionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProduction(production: ProductionEntity): Long

    @Insert
    suspend fun insertProductionMaterials(materials: List<ProductionMaterialEntity>)

    @Query("SELECT * FROM production_materials WHERE productionId = :productionId")
    fun getProductionMaterials(productionId: Long): Flow<List<ProductionMaterialEntity>>

    @Delete
    suspend fun deleteProduction(production: ProductionEntity)
}

/**
 * DAO برای عملیات فروش
 */
@Dao
interface SaleDao {
    @Query("SELECT * FROM sales ORDER BY timestamp DESC")
    fun getAllSales(): Flow<List<SaleEntity>>

    @Query("SELECT * FROM sales WHERE id = :id")
    fun getSaleById(id: Long): Flow<SaleEntity?>

    @Query("SELECT * FROM sales WHERE productId = :productId ORDER BY timestamp DESC")
    fun getSalesByProduct(productId: Long): Flow<List<SaleEntity>>

    @Query("SELECT * FROM sales ORDER BY timestamp DESC LIMIT :limit")
    fun getRecentSales(limit: Int): Flow<List<SaleEntity>>

    @Query("SELECT * FROM sales WHERE timestamp BETWEEN :startDate AND :endDate ORDER BY timestamp DESC")
    fun getSalesByDateRange(startDate: Long, endDate: Long): Flow<List<SaleEntity>>

    @Query("SELECT * FROM sales WHERE timestamp >= :startOfDay ORDER BY timestamp DESC")
    fun getTodaySales(startOfDay: Long): Flow<List<SaleEntity>>

    @Query("""
        SELECT * FROM sales
        WHERE timestamp >= :startOfMonth AND timestamp < :endOfMonth
        ORDER BY timestamp DESC
    """)
    fun getMonthlySales(startOfMonth: Long, endOfMonth: Long): Flow<List<SaleEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSale(sale: SaleEntity): Long

    @Delete
    suspend fun deleteSale(sale: SaleEntity)
}
