package com.costmaster.app.domain.model

import java.math.BigDecimal

/**
 * نمایش یک رکورد تولید
 */
data class Production(
    val id: Long = 0,
    val productId: Long,
    val productName: String,
    val quantity: Int,
    val totalCost: BigDecimal,
    val costPerUnit: BigDecimal,
    val materialCost: BigDecimal,
    val overheadCost: BigDecimal,
    val timestamp: Long = System.currentTimeMillis()
) {
    val profitPotential: BigDecimal
        get() = BigDecimal.ZERO // Calculated at sale time
}

/**
 * جزئیات مواد مصرف شده در تولید
 */
data class ProductionMaterial(
    val id: Long = 0,
    val productionId: Long,
    val materialId: Long,
    val materialName: String,
    val quantityUsed: BigDecimal,
    val materialUnit: MaterialUnit,
    val unitCost: BigDecimal,
    val totalCost: BigDecimal
)
