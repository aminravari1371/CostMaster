package com.costmaster.app.domain.model

import java.math.BigDecimal

/**
 * نمایش یک رکورد فروش
 */
data class Sale(
    val id: Long = 0,
    val productId: Long,
    val productName: String,
    val quantity: Int,
    val unitPrice: BigDecimal,
    val totalRevenue: BigDecimal,
    val costPerUnit: BigDecimal,
    val totalCost: BigDecimal,
    val grossProfit: BigDecimal,
    val timestamp: Long = System.currentTimeMillis()
) {
    val profitMarginPercent: BigDecimal
        get() = if (totalCost > BigDecimal.ZERO) {
            (grossProfit / totalCost) * BigDecimal(100)
        } else {
            BigDecimal.ZERO
        }
}

/**
 * نمایش یک هزینه سربار
 */
data class Overhead(
    val id: Long = 0,
    val name: String,
    val amount: BigDecimal,
    val type: OverheadType,
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * نوع سربار
 */
enum class OverheadType(val displayName: String) {
    FIXED("ثابت (ماهانه)"),
    PER_UNIT("متغیر (برای هر واحد)");

    companion object {
        fun fromDisplayName(name: String): OverheadType {
            return entries.find { it.displayName == name } ?: FIXED
        }
    }
}
