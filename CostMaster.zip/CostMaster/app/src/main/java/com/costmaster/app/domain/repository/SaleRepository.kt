package com.costmaster.app.domain.repository

import com.costmaster.app.domain.model.Sale
import kotlinx.coroutines.flow.Flow

/**
 * اینترفیس مخزن فروش
 */
interface SaleRepository {
    fun getAllSales(): Flow<List<Sale>>
    fun getSaleById(id: Long): Flow<Sale?>
    fun getSalesByProduct(productId: Long): Flow<List<Sale>>
    fun getRecentSales(limit: Int): Flow<List<Sale>>
    fun getSalesByDateRange(startDate: Long, endDate: Long): Flow<List<Sale>>
    fun getTodaySales(): Flow<List<Sale>>
    fun getMonthlySales(month: Int, year: Int): Flow<List<Sale>>
    suspend fun insertSale(sale: Sale): Long
    suspend fun deleteSale(sale: Sale)
}
