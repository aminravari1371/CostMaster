package com.costmaster.app.di

import com.costmaster.app.data.repository.MaterialRepositoryImpl
import com.costmaster.app.data.repository.ProductRepositoryImpl
import com.costmaster.app.data.repository.ProductionRepositoryImpl
import com.costmaster.app.data.repository.SaleRepositoryImpl
import com.costmaster.app.domain.repository.MaterialRepository
import com.costmaster.app.domain.repository.ProductRepository
import com.costmaster.app.domain.repository.ProductionRepository
import com.costmaster.app.domain.repository.SaleRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * ماژول Hilt برای مخزن‌ها
 */
@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds
    @Singleton
    abstract fun bindMaterialRepository(
        materialRepositoryImpl: MaterialRepositoryImpl
    ): MaterialRepository

    @Binds
    @Singleton
    abstract fun bindProductRepository(
        productRepositoryImpl: ProductRepositoryImpl
    ): ProductRepository

    @Binds
    @Singleton
    abstract fun bindProductionRepository(
        productionRepositoryImpl: ProductionRepositoryImpl
    ): ProductionRepository

    @Binds
    @Singleton
    abstract fun bindSaleRepository(
        saleRepositoryImpl: SaleRepositoryImpl
    ): SaleRepository
}
