package com.costmaster.app.ui.screens.reports

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.costmaster.app.domain.model.Material
import com.costmaster.app.domain.model.Product
import com.costmaster.app.domain.model.Production
import com.costmaster.app.domain.model.Sale
import com.costmaster.app.domain.usecase.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.math.BigDecimal
import javax.inject.Inject

/**
 * حالت صفحه گزارشات
 */
data class ReportsUiState(
    val materials: List<Material> = emptyList(),
    val products: List<Product> = emptyList(),
    val productions: List<Production> = emptyList(),
    val sales: List<Sale> = emptyList(),
    val isLoading: Boolean = true,
    val error: String? = null
)

/**
 * ViewModel برای صفحه گزارشات
 */
@HiltViewModel
class ReportsViewModel @Inject constructor(
    private val getAllMaterialsUseCase: GetAllMaterialsUseCase,
    private val getAllProductsUseCase: GetAllProductsUseCase,
    private val getAllProductionsUseCase: GetAllProductionsUseCase,
    private val getAllSalesUseCase: GetAllSalesUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(ReportsUiState())
    val uiState: StateFlow<ReportsUiState> = _uiState.asStateFlow()

    // آمار کلی
    val totalInventoryValue: StateFlow<BigDecimal> = MutableStateFlow(BigDecimal.ZERO)
    val totalSales: StateFlow<BigDecimal> = MutableStateFlow(BigDecimal.ZERO)
    val totalProfit: StateFlow<BigDecimal> = MutableStateFlow(BigDecimal.ZERO)
    val totalProductions: StateFlow<Int> = MutableStateFlow(0)

    init {
        loadData()
    }

    private fun loadData() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            try {
                combine(
                    getAllMaterialsUseCase(),
                    getAllProductsUseCase(),
                    getAllProductionsUseCase(),
                    getAllSalesUseCase()
                ) { materials, products, productions, sales ->
                    // محاسبه ارزش انبار مواد اولیه
                    val inventoryValue = materials.fold(BigDecimal.ZERO) { acc, material ->
                        acc + material.totalValue
                    }

                    // محاسبه مجموع فروش
                    val totalSalesValue = sales.fold(BigDecimal.ZERO) { acc, sale ->
                        acc + sale.totalRevenue
                    }

                    // محاسبه سود کل
                    val totalProfitValue = sales.fold(BigDecimal.ZERO) { acc, sale ->
                        acc + sale.grossProfit
                    }

                    // مجموع تولید
                    val totalProductionsCount = productions.sumOf { it.quantity }

                    _uiState.update {
                        it.copy(
                            materials = materials,
                            products = products,
                            productions = productions,
                            sales = sales,
                            isLoading = false
                        )
                    }

                    // به‌روزرسانی آمار
                    (totalInventoryValue as MutableStateFlow).value = inventoryValue
                    (totalSales as MutableStateFlow).value = totalSalesValue
                    (totalProfit as MutableStateFlow).value = totalProfitValue
                    (totalProductions as MutableStateFlow).value = totalProductionsCount
                }.collect()
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        error = e.message
                    )
                }
            }
        }
    }
}
