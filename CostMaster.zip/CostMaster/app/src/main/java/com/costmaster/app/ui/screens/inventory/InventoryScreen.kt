package com.costmaster.app.ui.screens.inventory

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.costmaster.app.domain.model.Material
import com.costmaster.app.domain.model.Product
import java.math.BigDecimal
import java.text.NumberFormat
import java.util.Locale

/**
 * صفحه اصلی انبار
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InventoryScreen(
    onAddMaterial: () -> Unit,
    onAddProduct: () -> Unit,
    viewModel: InventoryViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    var showAddStockDialog by remember { mutableStateOf<Material?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("مدیریت انبار") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    if (uiState.selectedTab == 0) onAddMaterial() else onAddProduct()
                },
                containerColor = MaterialTheme.colorScheme.secondary
            ) {
                Icon(Icons.Default.Add, contentDescription = "افزودن")
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // تب‌ها
            TabRow(
                selectedTabIndex = uiState.selectedTab,
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                Tab(
                    selected = uiState.selectedTab == 0,
                    onClick = { viewModel.onTabSelected(0) },
                    text = { Text("مواد اولیه") }
                )
                Tab(
                    selected = uiState.selectedTab == 1,
                    onClick = { viewModel.onTabSelected(1) },
                    text = { Text("محصولات") }
                )
            }

            // جستجو
            OutlinedTextField(
                value = uiState.searchQuery,
                onValueChange = viewModel::onSearchQueryChange,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                placeholder = { Text("جستجو...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true
            )

            if (uiState.isLoading) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            } else if (uiState.selectedTab == 0) {
                MaterialsList(
                    materials = uiState.materials,
                    onAddStock = { showAddStockDialog = it }
                )
            } else {
                ProductsList(products = uiState.products)
            }
        }

        // دیالوگ افزودن موجودی
        showAddStockDialog?.let { material ->
            AddStockDialog(
                material = material,
                onDismiss = { showAddStockDialog = null },
                onConfirm = { quantity, price ->
                    viewModel.addToStock(material.id, quantity, price)
                    showAddStockDialog = null
                }
            )
        }
    }
}

@Composable
fun MaterialsList(
    materials: List<Material>,
    onAddStock: (Material) -> Unit
) {
    if (materials.isEmpty()) {
        EmptyState(message = "هیچ ماده اولیه‌ای ثبت نشده است")
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(materials) { material ->
                MaterialCard(material = material, onAddStock = { onAddStock(material) })
            }
        }
    }
}

@Composable
fun MaterialCard(
    material: Material,
    onAddStock: () -> Unit
) {
    val format = NumberFormat.getNumberInstance(Locale.getDefault())

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (material.isLowStock) {
                MaterialTheme.colorScheme.errorContainer
            } else {
                MaterialTheme.colorScheme.surface
            }
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = material.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    if (material.isLowStock) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(
                            Icons.Default.Warning,
                            contentDescription = "موجودی کم",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "موجودی: ${format.format(material.currentStock)} ${material.unit.displayName}",
                    style = MaterialTheme.typography.bodyMedium
                )
                Text(
                    text = "قیمت: ${format.format(material.purchasePrice)} تومان",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Button(onClick = onAddStock) {
                Text("افزودن موجودی")
            }
        }
    }
}

@Composable
fun ProductsList(products: List<Product>) {
    if (products.isEmpty()) {
        EmptyState(message = "هیچ محصولی ثبت نشده است")
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(products) { product ->
                ProductCard(product = product)
            }
        }
    }
}

@Composable
fun ProductCard(product: Product) {
    val format = NumberFormat.getNumberInstance(Locale.getDefault())

    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = product.name,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "موجودی: ${product.currentStock} عدد",
                    style = MaterialTheme.typography.bodyMedium
                )
                Text(
                    text = "قیمت فروش: ${format.format(product.salePrice)} تومان",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
            if (product.estimatedCost > BigDecimal.ZERO) {
                Text(
                    text = "بهای تمام شده: ${format.format(product.estimatedCost)} تومان",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

@Composable
fun EmptyState(message: String) {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = message,
            style = MaterialTheme.typography.bodyLarge,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun AddStockDialog(
    material: Material,
    onDismiss: () -> Unit,
    onConfirm: (BigDecimal, BigDecimal) -> Unit
) {
    var quantity by remember { mutableStateOf("") }
    var price by remember { mutableStateOf(material.purchasePrice.toPlainString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("افزودن موجودی: ${material.name}") },
        text = {
            Column {
                OutlinedTextField(
                    value = quantity,
                    onValueChange = { quantity = it },
                    label = { Text("مقدار") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = price,
                    onValueChange = { price = it },
                    label = { Text("قیمت خرید (تومان)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val qty = quantity.toBigOrNull() ?: return@Button
                    val prc = price.toBigOrNull() ?: return@Button
                    onConfirm(qty, prc)
                }
            ) {
                Text("تأیید")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("لغو")
            }
        }
    )
}
