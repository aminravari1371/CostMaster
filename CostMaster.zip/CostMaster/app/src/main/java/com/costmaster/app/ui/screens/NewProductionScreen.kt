package com.costmaster.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.costmaster.app.domain.model.Product
import com.costmaster.app.domain.model.ProductMaterial
import com.costmaster.app.ui.screens.production.ProductionViewModel
import java.math.BigDecimal
import java.text.NumberFormat
import java.util.*

/**
 * صفحه ثبت تولید جدید
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewProductionScreen(
    onNavigateBack: () -> Unit,
    viewModel: ProductionViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    var selectedProduct by remember { mutableStateOf<Product?>(null) }
    var quantity by remember { mutableStateOf("1") }
    var expanded by remember { mutableStateOf(false) }
    var showConfirmDialog by remember { mutableStateOf(false) }

    val format = NumberFormat.getNumberInstance(Locale.getDefault())
    val isFormValid = selectedProduct != null &&
            (quantity.toIntOrNull() ?: 0) > 0

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("ثبت تولید جدید") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // انتخاب محصول
            ExposedDropdownMenuBox(
                expanded = expanded,
                onExpandedChange = { expanded = !expanded }
            ) {
                OutlinedTextField(
                    value = selectedProduct?.name ?: "",
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("انتخاب محصول") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .menuAnchor()
                )
                ExposedDropdownMenu(
                    expanded = expanded,
                    onDismissRequest = { expanded = false }
                ) {
                    uiState.products.forEach { product ->
                        DropdownMenuItem(
                            text = {
                                Column {
                                    Text(product.name)
                                    Text(
                                        text = "موجودی: ${product.currentStock} عدد",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            },
                            onClick = {
                                selectedProduct = product
                                viewModel.selectProduct(product)
                                expanded = false
                            }
                        )
                    }
                }
            }

            // تعداد تولید
            OutlinedTextField(
                value = quantity,
                onValueChange = { quantity = it },
                label = { Text("تعداد تولید") },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true
            )

            // نمایش فرمول و مواد مورد نیاز
            selectedProduct?.let { product ->
                FormulaPreview(
                    formula = viewModel.productFormula.value,
                    quantity = quantity.toIntOrNull() ?: 1,
                    overheadPerUnit = product.overheadPerUnit
                )
            }

            Spacer(modifier = Modifier.weight(1f))

            Button(
                onClick = { showConfirmDialog = true },
                modifier = Modifier.fillMaxWidth(),
                enabled = isFormValid
            ) {
                Text("ثبت تولید")
            }
        }

        // دیالوگ تأیید
        if (showConfirmDialog && selectedProduct != null) {
            ConfirmProductionDialog(
                productName = selectedProduct!!.name,
                quantity = quantity.toIntOrNull() ?: 1,
                estimatedCost = selectedProduct!!.estimatedCost,
                onConfirm = {
                    viewModel.createProduction(selectedProduct!!, quantity.toIntOrNull() ?: 1)
                    showConfirmDialog = false
                    onNavigateBack()
                },
                onDismiss = { showConfirmDialog = false }
            )
        }
    }
}

@Composable
fun FormulaPreview(
    formula: List<ProductMaterial>,
    quantity: Int,
    overheadPerUnit: BigDecimal
) {
    val format = NumberFormat.getNumberInstance(Locale.getDefault())
    val requiredQuantity = quantity

    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "مواد مورد نیاز",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))

            if (formula.isEmpty()) {
                Text(
                    text = "فرمول ساخت تعریف نشده است",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.error
                )
            } else {
                formula.forEach { item ->
                    val totalNeeded = item.quantityRequired * BigDecimal(requiredQuantity)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = item.materialName,
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            text = "${format.format(totalNeeded)} ${item.materialUnit.displayName}",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                val totalOverhead = overheadPerUnit * BigDecimal(requiredQuantity)
                Text(
                    text = "سربار: ${format.format(totalOverhead)} تومان",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

@Composable
fun ConfirmProductionDialog(
    productName: String,
    quantity: Int,
    estimatedCost: BigDecimal,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    val format = NumberFormat.getNumberInstance(Locale.getDefault())
    val totalCost = estimatedCost * BigDecimal(quantity)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تأیید تولید") },
        text = {
            Column {
                Text("محصول: $productName")
                Text("تعداد: $quantity")
                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                Text(
                    text = "هزینه کل: ${format.format(totalCost)} تومان",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        confirmButton = {
            Button(onClick = onConfirm) {
                Text("تأیید")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("لغو")
            }
        }
    )
}
