package com.costmaster.app.data.repository

import com.costmaster.app.data.local.dao.MaterialDao
import com.costmaster.app.data.mapper.toDomain
import com.costmaster.app.data.mapper.toEntity
import com.costmaster.app.domain.model.Material
import com.costmaster.app.domain.repository.MaterialRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.math.BigDecimal
import javax.inject.Inject

/**
 * پیاده‌سازی مخزن مواد اولیه
 */
class MaterialRepositoryImpl @Inject constructor(
    private val materialDao: MaterialDao
) : MaterialRepository {

    override fun getAllMaterials(): Flow<List<Material>> =
        materialDao.getAllMaterials().map { entities ->
            entities.map { it.toDomain() }
        }

    override fun getMaterialById(id: Long): Flow<Material?> =
        materialDao.getMaterialById(id).map { it?.toDomain() }

    override fun searchMaterials(query: String): Flow<List<Material>> =
        materialDao.searchMaterials(query).map { entities ->
            entities.map { it.toDomain() }
        }

    override suspend fun insertMaterial(material: Material): Long =
        materialDao.insertMaterial(material.toEntity())

    override suspend fun updateMaterial(material: Material) =
        materialDao.updateMaterial(material.toEntity().copy(updatedAt = System.currentTimeMillis()))

    override suspend fun deleteMaterial(material: Material) =
        materialDao.deleteMaterial(material.toEntity())

    override suspend fun updateStock(materialId: Long, newStock: BigDecimal) {
        materialDao.updateStock(materialId, newStock.toPlainString())
    }

    override suspend fun addToStock(materialId: Long, quantity: BigDecimal, purchasePrice: BigDecimal) {
        val material = materialDao.getMaterialByIdSync(materialId)
        if (material != null) {
            val currentStock = BigDecimal(material.currentStock)
            val currentTotalValue = currentStock * BigDecimal(material.purchasePrice)
            val newTotalValue = currentTotalValue + (quantity * purchasePrice)
            val newStock = currentStock + quantity
            val newAveragePrice = if (newStock > BigDecimal.ZERO) {
                newTotalValue / newStock
            } else {
                purchasePrice
            }

            materialDao.updateStock(
                materialId = materialId,
                newStock = newStock.toPlainString()
            )
        }
    }

    override fun getLowStockMaterials(): Flow<List<Material>> =
        materialDao.getLowStockMaterials().map { entities ->
            entities.map { it.toDomain() }
        }
}
